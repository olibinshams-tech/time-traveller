
export type TimelineType = 'Child' | 'Prime' | 'Elderly' | 'Original';

export interface TransformationResult {
  type: TimelineType;
  imageUrl: string;
}

export interface ProcessingState {
  isProcessing: boolean;
  step: string;
  progress: number;
}
