
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Upload, RefreshCcw, Share2, Sparkles, AlertCircle, Menu, Zap, Send, LayoutGrid, ChevronRight, Binary, Cpu, Activity, Gauge, Download, Check, Save, Trash2, Clock, Globe, Volume2, VolumeX, Calendar, Timer } from 'lucide-react';
import { transformImage } from './services/geminiService';
import { TimelineType, TransformationResult, ProcessingState } from './types';

const STORAGE_KEY = 'TIME_TRAVELLER_ORIGINAL_IMAGE';

// --- Sound Engine ---
const useTemporalSound = () => {
  const audioCtx = useRef<AudioContext | null>(null);
  const humOsc = useRef<OscillatorNode | null>(null);
  const humGain = useRef<GainNode | null>(null);
  const [isMuted, setIsMuted] = useState(true);

  const initAudio = () => {
    if (!audioCtx.current) {
      audioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const startHum = useCallback(() => {
    if (isMuted) return;
    initAudio();
    if (!audioCtx.current) return;

    const ctx = audioCtx.current;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(55, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 10);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(200, ctx.currentTime);
    
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.setValueAtTime(2, ctx.currentTime);
    lfoGain.gain.setValueAtTime(100, ctx.currentTime);
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 1);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    humOsc.current = osc;
    humGain.current = gain;
  }, [isMuted]);

  const stopHum = useCallback(() => {
    if (humOsc.current && humGain.current && audioCtx.current) {
      const ctx = audioCtx.current;
      humGain.current.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
      humOsc.current.stop(ctx.currentTime + 0.5);
      humOsc.current = null;
    }
  }, []);

  const playSuccess = useCallback(() => {
    if (isMuted) return;
    initAudio();
    if (!audioCtx.current) return;
    const ctx = audioCtx.current;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.1);
    
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  }, [isMuted]);

  const playError = useCallback(() => {
    if (isMuted) return;
    initAudio();
    if (!audioCtx.current) return;
    const ctx = audioCtx.current;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(100, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(50, ctx.currentTime + 0.3);
    
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.3);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  }, [isMuted]);

  return { isMuted, setIsMuted, startHum, stopHum, playSuccess, playError };
};

const TemporalLoader: React.FC<{ state: ProcessingState; targetYear: number }> = ({ state, targetYear }) => {
  const [displayYear, setDisplayYear] = useState(targetYear);
  const [flickerMsg, setFlickerMsg] = useState('');

  const messages = [
    'CALIBRATING FLUX CAPACITOR',
    'STABILIZING CHRONO-CORE',
    'SYNCHRONIZING TEMPORAL COORDS',
    'MINING QUANTUM DATA',
    'DILATING TIME PLANES',
    'AVOIDING PARADOXES',
    'BUFFERING DIMENSIONAL SHIFT'
  ];

  useEffect(() => {
    let yearInterval: number;
    let msgInterval: number;

    if (state.isProcessing) {
      yearInterval = window.setInterval(() => {
        setDisplayYear(prev => {
          const target = (targetYear - 50) + Math.floor(Math.random() * 100);
          return target;
        });
      }, 80);

      msgInterval = window.setInterval(() => {
        setFlickerMsg(messages[Math.floor(Math.random() * messages.length)]);
      }, 1500);
    }

    return () => {
      clearInterval(yearInterval);
      clearInterval(msgInterval);
    };
  }, [state.isProcessing, targetYear]);

  if (!state.isProcessing) return null;

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#0d1117]/95 backdrop-blur-md rounded-2xl overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        {[...Array(5)].map((_, i) => (
          <div 
            key={i} 
            className="temporal-ring" 
            style={{ 
              width: `${(i + 1) * 100}px`, 
              height: `${(i + 1) * 100}px`,
              animationDelay: `${i * 0.2}s`,
              borderWidth: i === 2 ? '4px' : '1px'
            }} 
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center space-y-8 text-center px-6">
        <div className="relative">
          <Clock className="w-16 h-16 text-cyan-400 animate-pulse" />
          <div className="absolute -inset-4 border border-cyan-500/20 rounded-full animate-spin" style={{ animationDuration: '3s' }} />
        </div>

        <div className="space-y-2">
          <div className="text-5xl font-black text-white font-mono tracking-tighter tabular-nums flex items-center justify-center">
             <span className="opacity-20 mr-1">T-</span>
             {displayYear}
          </div>
          <div className="text-[10px] font-bold text-cyan-500 uppercase tracking-[0.4em] font-mono h-4">
            {state.step || flickerMsg}
          </div>
        </div>

        <div className="w-64 space-y-4">
          <div className="flex justify-between items-end">
            <span className="text-[8px] font-mono text-slate-500 uppercase">Energy Levels</span>
            <span className="text-[10px] font-mono text-cyan-400">{state.progress}%</span>
          </div>
          <div className="h-2 bg-slate-900 border border-slate-800 rounded-full p-0.5 overflow-hidden shadow-inner">
            <div 
              className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 rounded-full transition-all duration-500 ease-out shadow-[0_0_10px_rgba(34,211,238,0.5)]"
              style={{ width: `${state.progress}%` }}
            />
          </div>
        </div>
      </div>
      <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500/10 shadow-[0_0_20px_rgba(34,211,238,0.5)] animate-bounce" style={{ animationDuration: '4s' }} />
    </div>
  );
};

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<string | null>(() => {
    return localStorage.getItem(STORAGE_KEY);
  });
  
  const [results, setResults] = useState<TransformationResult[]>([]);
  const [loading, setLoading] = useState<ProcessingState>({
    isProcessing: false,
    step: '',
    progress: 0
  });
  const [error, setError] = useState<string | null>(null);
  
  // Temporal Coordinates State
  const [destYear, setDestYear] = useState<number>(2024);
  const [destDate, setDestDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [destTime, setDestTime] = useState<string>("12:00");

  const fileInputRef = useRef<HTMLInputElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  
  const { isMuted, setIsMuted, startHum, stopHum, playSuccess, playError } = useTemporalSound();

  useEffect(() => {
    const scrambleText = (text: string) => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&";
      let iterations = 0;
      
      const interval = setInterval(() => {
        if (!titleRef.current) return;
        
        titleRef.current.innerText = text.split("")
          .map((letter, index) => {
            if (index < iterations) return text[index];
            return chars[Math.floor(Math.random() * chars.length)];
          })
          .join("");
        
        if (iterations >= text.length) clearInterval(interval);
        iterations += 1/3;
      }, 30);
    };

    scrambleText("TIME TRAVELLER");

    if (originalImage) {
      setResults([{ type: 'Original', imageUrl: originalImage }]);
    }
  }, []);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setOriginalImage(result);
        try {
          localStorage.setItem(STORAGE_KEY, result);
        } catch (err) {
          console.warn("LocalStorage quota exceeded.");
        }
        processTimeline(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const processTimeline = async (image: string) => {
    setLoading({ isProcessing: true, step: 'INITIATING CHRONO-CORE', progress: 5 });
    setResults([{ type: 'Original', imageUrl: image }]);
    setError(null);
    startHum();

    // Logic for dynamic temporal tasks
    const tasks = [
      { 
        type: 'Child', 
        year: destYear - 40,
        prompt: `Transform this person into a adorable 5-year-old version of themselves. The photo should look like it was taken on ${destDate} at ${destTime} in the year ${destYear - 40}. Match the photography style of that specific era.` 
      },
      { 
        type: 'Prime', 
        year: destYear,
        prompt: `Transform this person into their absolute prime version (approx 25 years old). The photo is taken on ${destDate} at ${destTime} in the year ${destYear}. Use lighting and atmosphere consistent with that time period.` 
      },
      { 
        type: 'Elderly', 
        year: destYear + 40,
        prompt: `Transform this person into a distinguished elderly version of themselves (approx 80 years old). The photo is taken on ${destDate} at ${destTime} in the year ${destYear + 40}. Capture a futuristic or aged aesthetic relevant to that year.` 
      }
    ];

    try {
      const resultsArray: TransformationResult[] = [
        { type: 'Original', imageUrl: image }
      ];

      for (let i = 0; i < tasks.length; i++) {
        setLoading(prev => ({
          ...prev,
          step: `TEMPORAL SHIFT: ${tasks[i].year}`,
          progress: 10 + (i * 30)
        }));

        const transformedUrl = await transformImage(image, tasks[i].prompt);
        if (transformedUrl) {
          resultsArray.push({ type: tasks[i].type as TimelineType, imageUrl: transformedUrl });
          setResults([...resultsArray]);
        }
      }

      setLoading({ isProcessing: false, step: 'SYNC COMPLETE', progress: 100 });
      stopHum();
      playSuccess();
    } catch (err) {
      console.error(err);
      setError("TEMPORAL_ERROR: Coordinate calculation failed.");
      setLoading({ isProcessing: false, step: '', progress: 0 });
      stopHum();
      playError();
    }
  };

  const handleDownload = (imageUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const purgeSession = () => {
    setOriginalImage(null);
    setResults([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  const getLabel = (type: string) => {
    switch (type) {
      case 'Original': return 'TARGET: ORIGIN';
      case 'Child': return `EPOCH: ${destYear - 40}`;
      case 'Prime': return `EPOCH: ${destYear}`;
      case 'Elderly': return `EPOCH: ${destYear + 40}`;
      default: return type;
    }
  };

  return (
    <div className="min-h-screen bg-[#0d1117] text-[#c9d1d9] font-sans p-4 md:p-8 selection:bg-cyan-500/30">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[10%] left-[10%] w-[30%] h-[30%] rounded-full bg-cyan-950/10 blur-[120px]" />
        <div className="absolute bottom-[10%] right-[10%] w-[30%] h-[30%] rounded-full bg-purple-950/10 blur-[120px]" />
      </div>

      <div className="max-w-6xl mx-auto space-y-12 relative z-10">
        
        <nav className="flex flex-col items-center justify-center pt-8 pb-12 relative">
          <div className="portal-ring"></div>
          
          <div className="flex flex-col items-center text-center">
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex flex-col text-right hidden md:flex">
                <span className="segmented-label">DEST_YEAR: {destYear}</span>
                <span className="segmented-label">SYNC: {loading.isProcessing ? 'WARPING' : 'LOCKED'}</span>
              </div>
              <div className="p-3 bg-cyan-500/10 rounded-full border border-cyan-500/40 shadow-[0_0_15px_rgba(34,211,238,0.3)]">
                <Zap className="w-8 h-8 text-cyan-400" fill="currentColor" />
              </div>
              <div className="flex flex-col text-left hidden md:flex">
                <span className="segmented-label">TIME: {destTime}</span>
                <span className="segmented-label">CHRONO: {loading.progress}%</span>
              </div>
            </div>
            
            <h1 ref={titleRef} className="time-machine-text" id="app-title">
              TIME TRAVELLER
            </h1>
          </div>

          <button 
            onClick={() => setIsMuted(!isMuted)}
            className="absolute top-0 right-0 p-3 bg-[#161b22] border border-[#30363d] rounded-xl hover:bg-[#21262d] transition-all text-slate-400 hover:text-cyan-400"
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column - Controls & Temporal Inputs */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Temporal Coordinates Dashboard */}
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-sm">
              <h3 className="text-[10px] font-bold text-cyan-500 mb-6 uppercase tracking-[0.2em] flex items-center">
                <Globe className="w-3 h-3 mr-2" />
                TEMPORAL_COORDINATES // DESTINATION
              </h3>
              
              <div className="space-y-6">
                {/* Year Selection */}
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <label className="text-[10px] font-mono text-slate-500 uppercase">Target Year</label>
                    <span className="text-xs font-mono text-cyan-400">{destYear}</span>
                  </div>
                  <input 
                    type="range" 
                    min="1900" 
                    max="2150" 
                    value={destYear} 
                    onChange={(e) => setDestYear(parseInt(e.target.value))}
                    className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                  <div className="flex justify-between text-[8px] font-mono text-slate-700">
                    <span>1900</span>
                    <span>2024</span>
                    <span>2150</span>
                  </div>
                </div>

                {/* Date Selection */}
                <div className="space-y-3">
                  <label className="text-[10px] font-mono text-slate-500 uppercase block">Epoch Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-500/50" />
                    <input 
                      type="date" 
                      value={destDate}
                      onChange={(e) => setDestDate(e.target.value)}
                      className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl py-3 pl-10 pr-4 text-xs text-white font-mono focus:border-cyan-500 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Time Selection */}
                <div className="space-y-3">
                  <label className="text-[10px] font-mono text-slate-500 uppercase block">Chrono Moment</label>
                  <div className="relative">
                    <Timer className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-500/50" />
                    <input 
                      type="time" 
                      value={destTime}
                      onChange={(e) => setDestTime(e.target.value)}
                      className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl py-3 pl-10 pr-4 text-xs text-white font-mono focus:border-cyan-500 outline-none transition-all"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Upload Box */}
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-sm relative overflow-hidden group">
              <h3 className="text-[10px] font-bold text-cyan-500 mb-4 uppercase tracking-[0.2em] flex items-center">
                <Cpu className="w-3 h-3 mr-2" />
                BIO_TRANSCEIVER // IN
              </h3>
              <div 
                onClick={() => !loading.isProcessing && fileInputRef.current?.click()}
                className={`cursor-pointer bg-[#0d1117] border border-[#30363d] rounded-xl p-4 transition-all hover:border-cyan-500/50 hover:bg-[#1c2128] group/box ${loading.isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className="border border-dashed border-[#30363d] rounded-lg p-6 flex flex-col items-center justify-center space-y-3 group-hover/box:border-cyan-500/30">
                  {originalImage ? (
                    <div className="w-full aspect-square rounded-lg overflow-hidden border border-cyan-500/20 shadow-inner">
                      <img src={originalImage} alt="Persisted" className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-[#21262d] rounded-full border border-white/5 shadow-inner">
                        <Upload className="w-6 h-6 text-slate-400 group-hover/box:text-cyan-400 transition-colors" />
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono uppercase mt-3">FEED_SUBJECT.dat</span>
                    </div>
                  )}
                </div>
              </div>
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*" />
            </div>

            {/* Matrix distribution Controls */}
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-sm">
              <div className="flex flex-col gap-3">
                <div className="flex gap-2">
                  <button 
                    onClick={() => originalImage && processTimeline(originalImage)}
                    disabled={!originalImage || loading.isProcessing}
                    className="flex-1 bg-cyan-600 hover:bg-cyan-500 disabled:bg-cyan-900 disabled:text-slate-500 text-slate-950 font-black py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all shadow-lg active:scale-95 flex items-center justify-center"
                  >
                     <RefreshCcw className={`w-3 h-3 mr-2 ${loading.isProcessing ? 'animate-spin' : ''}`} />
                     RECALIBRATE
                  </button>
                  <button 
                    onClick={purgeSession}
                    disabled={loading.isProcessing}
                    className="flex-1 bg-[#21262d] border border-[#30363d] hover:bg-[#30363d] text-white font-black py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center disabled:opacity-50"
                  >
                    <Trash2 className="w-3 h-3 mr-2" />
                    PURGE
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Results */}
          <div className="lg:col-span-8 space-y-6">
            
            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 shadow-sm min-h-[500px] relative">
              <TemporalLoader state={loading} targetYear={destYear} />
              
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] flex items-center">
                  <LayoutGrid className="w-3 h-3 mr-2" />
                  RECONSTRUCTION // ANALYZER
                </h3>
                <div className="flex space-x-1">
                  <div className={`w-1.5 h-1.5 rounded-full ${loading.isProcessing ? 'bg-red-500 animate-ping' : 'bg-red-500/20'}`} />
                  <div className={`w-1.5 h-1.5 rounded-full ${loading.isProcessing ? 'bg-cyan-500 animate-pulse' : 'bg-cyan-500/20'}`} />
                </div>
              </div>

              {error && (
                <div className="mb-6 p-4 bg-red-500/5 border border-red-500/20 rounded-xl flex items-center text-red-400 text-xs font-mono">
                  <AlertCircle className="w-4 h-4 mr-3 flex-shrink-0" />
                  ERR_TEMPORAL_FAILURE: {error}
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-2 gap-6">
                {['Original', 'Child', 'Prime', 'Elderly'].map((type) => {
                  const result = results.find(r => r.type === type);
                  return (
                    <div key={type} className={`relative group rounded-xl overflow-hidden border transition-all duration-500 ${result ? 'border-[#30363d] hover:border-cyan-500/50 shadow-2xl' : 'border-[#21262d]'}`}>
                      <div className="aspect-[4/3] bg-[#0d1117] relative">
                        {result ? (
                          <>
                            <img src={result.imageUrl} alt={type} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
                            <div className="absolute top-3 right-3 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => handleDownload(result.imageUrl, `time-traveller-${type.toLowerCase()}.png`)} className="p-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg shadow-xl active:scale-90 transition-all"><Download className="w-4 h-4" /></button>
                            </div>
                          </>
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center opacity-30">
                            <Zap className="w-5 h-5 text-slate-700" />
                            <span className="mt-2 text-[8px] font-mono text-slate-800 uppercase">OFFLINE</span>
                          </div>
                        )}
                        
                        <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/95 via-black/60 to-transparent">
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <span className="text-[9px] text-cyan-500 font-mono block opacity-80">
                                {type === 'Original' ? 'ORIGIN_REF' : `${destDate} // ${destTime}`}
                              </span>
                              <span className="text-[11px] font-black text-white uppercase tracking-wider block font-mono">
                                {getLabel(type)}
                              </span>
                            </div>
                            {result && (type !== 'Original' ? <Check className="w-4 h-4 text-green-500" /> : <Activity className="w-4 h-4 text-cyan-500 animate-pulse" />)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl relative overflow-hidden">
               <div className="absolute bottom-0 left-0 w-full h-0.5 bg-cyan-500/20 overflow-hidden">
                  <div className="h-full bg-cyan-500 animate-scanline w-1/4" style={{ animationDuration: '3s' }} />
               </div>
               
              <div className="w-full md:w-auto space-y-4">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] font-mono">Transmission Module</h3>
                <div className="flex gap-3">
                  <button className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black px-6 py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center">
                    <Zap className="w-3 h-3 mr-2" />
                    ENGAGE HD
                  </button>
                  <button className="bg-white/5 border border-white/10 hover:bg-white/10 text-white font-black px-6 py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 flex items-center">
                    <Share2 className="w-3 h-3 mr-2" />
                    BROADCAST
                  </button>
                </div>
              </div>

              <div className="w-full md:w-64 bg-[#0d1117] border border-[#30363d] rounded-2xl p-4 flex items-center space-x-4 group cursor-pointer hover:border-cyan-500/30 transition-all">
                <div className="p-3 bg-cyan-500/10 rounded-xl text-cyan-400 border border-cyan-500/20 group-hover:bg-cyan-500/20 transition-all">
                  <Send className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="text-[10px] font-black text-white uppercase tracking-widest font-mono">CHRONO_BOT</h4>
                  <p className="text-[8px] text-slate-500 font-mono mt-0.5">NEURAL_LINK: ONLINE</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-12 grid grid-cols-1 md:grid-cols-3 gap-8 border-t border-[#161b22]">
          <div className="space-y-2 text-[10px] text-slate-500 font-mono tracking-tight opacity-40">
            <p>COORD_LAT: 37.7749° N</p>
            <p>COORD_LONG: 122.4194° W</p>
            <p>ENTITY_REF: 9X-ALPHA</p>
          </div>
          <div className="space-y-2 text-[10px] text-slate-500 font-mono tracking-tight opacity-40 text-center">
            <p>POWER: STABLE // 1.21 GW</p>
            <p>TEMPORAL_BUFFER: 100% CLEAR</p>
            <p>NODES: 7 / 12 / 19 ACTIVE</p>
          </div>
          <div className="flex flex-col md:items-end justify-center space-y-1">
            <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest font-mono">Access Points</p>
            <p className="font-mono text-[10px]">
              <span className="text-cyan-500/50 hover:text-cyan-500 cursor-pointer">secure.time.link</span> 
              <span className="mx-2 text-slate-800">|</span>
              <span className="text-cyan-500/50 hover:text-cyan-500 cursor-pointer">@shifter_bot</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
